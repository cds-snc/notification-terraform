# install requests module
pip install --target . requests
# zip the contents under the name dependencies.zip
zip -r dependencies.zip .
